<?php
/**
* Template Name: Standard Template
* Description: Used as a page template to show page contents, followed by a loop 
* through the Home page template
*/


//* Remove .site-inner
add_filter( 'genesis_markup_site-inner', '__return_null' );
add_filter( 'genesis_markup_content-sidebar-wrap_output', '__return_false' );
add_filter( 'genesis_markup_content', '__return_null' );
add_filter( 'genesis_markup_content-sidebar-wrap', '__return_null' );

genesis();